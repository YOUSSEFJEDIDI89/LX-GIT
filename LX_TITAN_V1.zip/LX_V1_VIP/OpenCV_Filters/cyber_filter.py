import cv2
def apply_lx_filter(frame):
    # LX High-Pass Cyber Filter
    return cv2.Canny(frame, 100, 200)