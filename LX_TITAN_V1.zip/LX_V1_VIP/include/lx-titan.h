#ifndef LX_TITAN_H
#define LX_TITAN_H

namespace LX {
    void ActivateShield(); // تفعيل المستوى 10
    bool CheckIntegrity(); // فحص سلامة الملفات
}

#endif
