/* AI Neural Weights */
#define AI_LEVEL 95