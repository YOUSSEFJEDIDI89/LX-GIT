/* Kernel Protection Logic */
