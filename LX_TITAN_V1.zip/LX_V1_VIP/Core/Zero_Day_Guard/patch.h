/* Cloud Security Patch v1.0 */
#define ZD_PROTECT 1