#include <iostream>
int main() { std::cout << "LX V1.0 Core Active"; return 0; }